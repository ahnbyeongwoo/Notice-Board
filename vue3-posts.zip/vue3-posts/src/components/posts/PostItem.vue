<template>
  <AppCard
    ><!-- AppCard 컴포넌트를 사용하여 카드 레이아웃 -->
    <h5 class="card-title">{{ title }}</h5>
    <p class="card-text">
      {{ content }}
    </p>
    <p class="text-muted">{{ createdAt }}</p>
  </AppCard>
</template>

<script setup>
import AppCard from '@/components/AppCard.vue'

defineProps({
  // 컴포넌트가 받을 props를 정의
  title: {
    type: String,
    required: true,
  },
  content: {
    type: String,
  },
  createdAt: {
    type: { String, Date, Number },
  },
})
</script>

<style lang="css" scoped></style>
