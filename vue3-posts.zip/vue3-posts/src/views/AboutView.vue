<template>
  <div>
    <h2>About View</h2>
    <p>{{ $route.path }}</p>
    <button class="btn-primary" @click="$router.push('/')">Home으로 이동</button
    ><!--버튼을 클릭하였을때 Home으로 이동-->
  </div>
</template>

<script setup>
import { useRoute } from 'vue-router'

const route = useRoute()
console.log('route.path: ', route.path)
</script>

<style lang="scss" scoped></style>
