<template>
  <div>
    <h2>{{ post.title }}</h2>
    <p>{{ post.content }}</p>
    <p class="text-muted">{{ post.createdAt }}</p>
    <hr class="my-4" />
    <div class="row g-2">
      <!--<div class="col-auto">
        이전글 버튼 (기능 미구현) 
        <button class="btn btn-outline-dark">이전글</button>
      </div>-->
      <!--<div class="col-auto">
        <button class="btn btn-outline-dark">다음글</button>
      </div>-->
      <div class="col-auto me-auto"></div>
      <div class="col-auto">
        <button class="btn btn-outline-dark" @click="goListPage">목록</button>
      </div>
      <div class="col-auto">
        <button class="btn btn-outline-primary" @click="goEditPage">
          수정
        </button>
      </div>
      <div class="col-auto">
        <button class="btn btn-outline-danger" @click="remove">삭제</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { getPostById, deletePost } from '@/api/posts'
import { ref } from 'vue'

const props = defineProps({
  id: Number, //게시글 id
})

const router = useRouter()

const post = ref({
  //게시글 데이터 저장
  title: null,
  content: null,
  createdAt: null,
})

const fetchPost = async () => {
  // 게시글 데이터를 서버에서 가져옴
  try {
    const { data } = await getPostById(props.id) // API 호출로 데이터
    setPost(data) // 가져온 데이터로 post 업데이트
  } catch (error) {
    console.error(error)
  }
}

const setPost = ({ title, content, createdAt }) => {
  // post 객체를 업데이트
  post.value.title = title
  post.value.content = content
  post.value.createdAt = createdAt
}

fetchPost()

const remove = async () => {
  try {
    if (confirm('삭제 하시겠습니까?') === false) {
      return
    }
    await deletePost(props.id) // API 호출로 게시글 삭제
    router.push({ name: 'PostList' }) // 삭제 후 목록 페이지로 이동
  } catch (error) {
    console.error(error)
  }
}

const goListPage = () => router.push({ name: 'PostList' }) // 목록 페이지로 이동하는 함수

// 수정 페이지로 이동하는 함수 (현재 게시글 ID와 함께)
const goEditPage = () =>
  router.push({ name: 'PostEdit', params: { id: props.id } })
</script>

<style lang="scss" scoped></style>
