<template>
  <div>
    <h2>게시글 등록</h2>
    <hr class="my-4" />
    <!-- 폼 제출 시 save 메서드 호출 -->
    <form @submit.prevent="save">
      <div class="mb-3">
        <label for="title" class="form-label">제목</label>
        <input
          v-model="form.title"
          type="text"
          class="form-control"
          id="title"
        />
      </div>
      <div class="mb-3">
        <label for="content" class="form-label">내용</label>
        <textarea
          v-model="form.content"
          class="form-control"
          id="content"
          rows="3"
        ></textarea>
      </div>
    </form>
  </div>
  <div class="pt-4">
    <button type="button" class="btn btn-outline-dark me-2" @click="goListPage">
      목록
    </button>
    <button type="button" class="btn btn-primary" @click="save">저장</button>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { createPost } from '@/api/posts'

const router = useRouter() // 라우터 인스턴스
const form = ref({
  title: null,
  content: null,
})

const save = () => {
  try {
    // 게시글 생성 API 호출
    createPost({
      ...form.value,
      createdAt: Date.now(), // 생성일시 추가
    })
    router.push({ name: 'PostList' }) // 등록 성공 시 목록 페이지로 이동
  } catch (error) {
    console.error(error)
  }
}

const goListPage = () => router.push({ name: 'PostList' }) //목록 페이지 이동
</script>

<style lang="scss" scoped></style>
