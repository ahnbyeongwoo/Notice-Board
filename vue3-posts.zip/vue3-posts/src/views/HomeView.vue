<template>
  <!-- 특정 URL로 들어왔을때 Home컴포넌트를 보여줄수 있도록 라우터 설정 -->
  <div>
    <h2>Home View</h2>
    <p>{{ $route.path }}</p>
    <p>{{ $route.name }}</p>
    <!--현재 페이지 -->
    <button class="btn-primary" @click="goAboutPage">About으로 이동</button
    ><!--버튼을 클릭하였을때 About으로 이동-->
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()
const goAboutPage = () => {
  router.push('/about')
}
</script>

<style lang="scss" scoped></style>
