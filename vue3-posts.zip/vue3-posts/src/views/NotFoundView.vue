<template>
  <div class="text-center py-5">
    <h1>Oops!</h1>
    <h2>404 Not Found</h2>
    <div class="text-muted">요청할 페이지를 찾을 수 없습니다.</div>
    <div class="mt-4">
      <RouterLink to="/"
        ><!--클릭했을때 홈으로 이동-->
        <button class="btn btn-primary">HOME</button>
      </RouterLink>
    </div>
  </div>
</template>

<script setup></script>

<style lang="css" scoped></style>
