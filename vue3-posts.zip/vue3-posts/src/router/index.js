import {
  createRouter,
  //createWebHashHistory,
  createWebHistory,
} from 'vue-router'

import HomeView from '@/views/HomeView.vue'
import AboutView from '@/views/AboutView.vue'
import PostCreateView from '@/views/posts/PostCreateView.vue'
import PostDetailView from '@/views/posts/PostDetailView.vue'
import PostListView from '@/views/posts/PostListView.vue'
import PostEditView from '@/views/posts/PostEditView.vue'
import NotFoundView from '@/views/NotFoundView.vue'
import NestedView from '@/views/nested/NestedView.vue'
import NestedOneView from '@/views/nested/NestedOneView.vue'
import NestedTwoView from '@/views/nested/NestedTwoView.vue'
import NestedHomeView from '@/views/nested/NestedHomeView.vue'

// 라우트 설정 배열
const routes = [
  // 홈 페이지 라우트
  {
    path: '/',
    name: 'Home',
    component: HomeView,
  },
  // About 페이지 라우트
  {
    path: '/about',
    name: 'About',
    component: AboutView,
  },
  // 게시글 목록
  {
    path: '/posts',
    name: 'PostList',
    component: PostListView,
  }, // 게시글 작성
  {
    path: '/posts/create',
    name: 'PostCreate',
    component: PostCreateView,
  }, // 게시글 상세
  {
    path: '/posts/:id',
    name: 'PostDetail',
    component: PostDetailView,
    props: route => ({
      id: parseInt(route.params.id), // ID를 숫자로 변환하여 전달
    }),
  },
  // 게시글 수정
  {
    path: '/posts/:id/edit',
    name: 'PostEdit',
    component: PostEditView,
  },
  // 존재하지 않는 경로 처리 (404 페이지)
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: NotFoundView,
  },
  // 중첩 라우트 설정
  {
    path: '/nested',
    name: 'Nested',
    component: NestedView,
    children: [
      {
        path: '',
        name: 'NestedHome',
        component: NestedHomeView,
      },
      {
        path: 'one',
        name: 'NestedOne',
        component: NestedOneView,
      },
      {
        path: 'two',
        name: 'NestedTwo',
        component: NestedTwoView,
      },
    ],
  },
]

// 라우터 인스턴스 생성
const router = createRouter({
  history: createWebHistory(), //히스토리 모드
  //history: createWebHas hHistory(), // 해시 모드 (주석 처리됨)
  routes, // 위에서 정의한 라우트 배열 사용
})

export default router
