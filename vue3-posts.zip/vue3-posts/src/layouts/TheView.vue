<template>
  <!--
    /로 요청이 들어왔을때 HomeView.vue로 렌더링
    /about으로 요청이 들어왔을때 AboutView.vue로 렌더링
  -->
  <main>
    <div class="container py-4">
      <RouterView></RouterView>
    </div>
  </main>
</template>

<script setup></script>

<style lang="css" scoped></style>
