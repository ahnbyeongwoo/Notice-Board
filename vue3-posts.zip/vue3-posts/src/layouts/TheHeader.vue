<template>
  <header>
    <nav class="navbar navbar-expand-sm navbar-dark bg-primary">
      <div class="container-fluid">
        <!-- 브랜드 로고 -->
        <a class="navbar-brand" href="#">GYM CODING</a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <!-- 네비게이션 링크 -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto">
            <li class="nav-item">
              <RouterLink class="nav-link" active-class="active" to="/"
                >Home</RouterLink
              >
            </li>
            <li class="nav-item">
              <!-- About 페이지로 이동 (페이지 리로딩 없이 싱글 페이지) -->
              <RouterLink class="nav-link" active-class="active" to="/about"
                >About</RouterLink
              >
            </li>
            <li class="nav-item">
              <RouterLink class="nav-link" active-class="active" to="/posts"
                >게시글</RouterLink
              >
            </li>
            <li class="nav-item">
              <RouterLink class="nav-link" active-class="active" to="/nested"
                >Nested</RouterLink
              >
            </li>
          </ul>
          <!-- 검색 및 글쓰기 버튼 -->
          <div class="d-flex" role="search">
            <!-- 글쓰기 페이지 이동 버튼 -->
            <button class="btn btn-outline-light" type="button" @click="goPage">
              글쓰기
            </button>
          </div>
        </div>
      </div>
    </nav>
  </header>
</template>

<script setup>
import { useRouter } from 'vue-router' // Vue Router 사용

const router = useRouter() // 라우터 인스턴스 생성
const goPage = () => {
  // 글쓰기 페이지로 라우팅
  router.push({
    name: 'PostCreate',
  })
}
</script>

<style lang="css" scoped></style>
